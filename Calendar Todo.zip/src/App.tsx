import React from "react"
import Home from "./pages/home"

function App() {

  return (
    <div className="main-container">
      <Home />
    </div>
  )
}

export default App
